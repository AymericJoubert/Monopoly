package monopoly.gui;
import monopoly.jeu.Player;
import monopoly.jeu.Cases;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import monopoly.jeu.Joueur;

public class Lancement extends JFrame implements ActionListener {

	private JTextField nomJoueur = new JTextField();
	private JButton ajoutJoueur = new JButton("Ajouter");
	private JButton jouer = new JButton("Jouer");
	private int cpt=0;
	public Lancement(){
		super("Monopoly");
		JPanel menu = new JPanel(new GridLayout(3,1));
		menu.add(nomJoueur);
		menu.add(ajoutJoueur);
		menu.add(jouer);
		this.setSize(300,300);
		this.setLocation(300,200);
		this.setContentPane(menu);
		this.setVisible(true);
		ajoutJoueur.addActionListener(this);
		jouer.addActionListener(this);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent e){
		cpt++;
		if(e.getActionCommand().equals("Ajouter")){
			new Player(cpt, nomJoueur.getText(), 20000, Cases.cases.get(0));
		}
		else{
			this.setVisible(false);
			JFrame f = new JFrame("Monopoly");
			int largeur = 810;
			int hauteur = 1350;
			f.setSize(hauteur+11,largeur+11);
			f.setResizable(true);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			Plateau p = new Plateau("monopoly", "config/monopoly.csv");
			f.setContentPane(p);
			f.setVisible(true);
			//p.actualiser();
			
		}
	}
	
	public static void main(String [] args){
		Lancement c = new Lancement();

	}
}
