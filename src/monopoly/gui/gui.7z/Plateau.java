package monopoly.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import monopoly.csv.Carte_CSV;
import monopoly.csv.Carte_Model;
import monopoly.csv.Monopoly_Model;
import monopoly.proprietes.*;

/** Cette classe est une interface graphique qui représente le plateau de jeu */
public class Plateau extends JPanel implements ActionListener {
	ArrayList<JPanel> cases = new ArrayList<JPanel>();
	JButton lancer = new JButton("Lancer !");
	public Plateau(String type, String fichier){
		this.setLayout(new GridBagLayout());
		//Lecture du fichier de configuration du plateau
		try{
			Carte_CSV carte = new Carte_CSV();
			
			//Implementation dans le plateau
			ArrayList<Monopoly_Model> plateau = (ArrayList<Monopoly_Model>)carte.instanciation_liste_cartes(type, fichier);
			Monopoly_Model plat;
			
			String line;
			String [] lineCase;

			
			/*while(line!=null){
				lineCase = line.split(";");
				plateau.add(lineCase);
				line=br.readLine();
			}
			String [] plat;    */ 	

			GridBagConstraints gbc = new GridBagConstraints();
			//On positionne la case de départ du composant
			gbc.gridx = 0;
			gbc.gridy = 0;
			//Le nombre de case en hauteur et en largeur qu'une case occupe
			gbc.gridheight = 1;
			gbc.gridwidth = 1;
			gbc.fill = GridBagConstraints.BOTH;
			gbc.weightx = 1;
			gbc.weighty = 1;

			for(int i=0; i<11; i++){
				gbc.gridx=i;
				for(int j=0; j<11; j++){
					JPanel jj = new JPanel(new BorderLayout());
					jj.setBackground(new Color(204,229,218));
					jj.setBorder(BorderFactory.createLineBorder(Color.black));
					gbc.gridy=j;
					if(i==0 && j==0){
						plat = plateau.get(10);
						jj.add(new JLabel(affiche(plateau.get(10).getNom())));
						this.add(jj, gbc);
						cases.add(jj);
					}
					else{
						if(i==0){
							plat = plateau.get(10-j);
							JPanel couleur = new JPanel();
							if(plat.getType_evenement().equals("terrain")){
								couleur.setBackground(couleur(plat.getGroupe()));
								jj.add(couleur, BorderLayout.EAST);							
						}
							else{
								couleur.setBackground(Color.WHITE);
								jj.add(couleur, BorderLayout.EAST);
							}
							jj.add(new JLabel(affiche(plat.getNom())));
							this.add(jj, gbc);
							cases.add(jj);

						}
						else{
							if(j==0){
								plat = plateau.get(10+i);
								JPanel couleur = new JPanel();
								if(plat.getType_evenement().equals("terrain")){
									couleur.setBackground(couleur(plat.getGroupe()));
									jj.add(couleur, BorderLayout.SOUTH);							
								}
								else{
									couleur.setBackground(Color.WHITE);
									jj.add(couleur, BorderLayout.SOUTH);
								}
								jj.add(new JLabel(affiche(plat.getNom())));
								this.add(jj, gbc);
								cases.add(jj);
							}
							else{
								if(i==10){
									plat = plateau.get(20+j);
									JPanel couleur = new JPanel();
									if(plat.getType_evenement().equals("terrain")){
										couleur.setBackground(couleur(plat.getGroupe()));
										jj.add(couleur, BorderLayout.WEST);							
									}
									else{
										couleur.setBackground(Color.WHITE);
										jj.add(couleur, BorderLayout.WEST);
									}
									jj.add(new JLabel(affiche(plat.getNom())));
									this.add(jj, gbc);
									cases.add(jj);

								}
								else{
									if(j==10 && i!=0){
										plat = plateau.get(30+10-i);
										JPanel couleur = new JPanel();
										if(plat.getType_evenement().equals("terrain")){
											couleur.setBackground(couleur(plat.getGroupe()));
											jj.add(couleur, BorderLayout.NORTH);							
										}
										else{
											couleur.setBackground(Color.WHITE);
											jj.add(couleur, BorderLayout.NORTH);
										}
										jj.add(new JLabel(affiche(plat.getNom())));
										this.add(jj, gbc);
										cases.add(jj);
									}
									else{
										if(i==1 && j==1){
											gbc.gridheight = 9;
											gbc.gridwidth = 9;
											JPanel infosJeu = new JPanel(new GridLayout(1,3));
											JPanel deco = new JPanel(new GridLayout(1,3));
											deco.setBackground(new Color(204,229,218));
											ImageIcon monopoly = new ImageIcon(new ImageIcon("monopoly.jpg").getImage().getScaledInstance(230, 300, Image.SCALE_DEFAULT));
											deco.add(new JLabel(new ImageIcon("chance.gif")));
											deco.add(new JLabel(monopoly));
											deco.add(new JLabel(new ImageIcon("communaute.gif")));				
											JTextField argent = new JTextField("Argent : 0");
											JTextField des = new JTextField("Des : 0");
											des.setHorizontalAlignment(JTextField.RIGHT);
											lancer.addActionListener(this);
											infosJeu.add(argent);											
											infosJeu.add(lancer);
											infosJeu.add(des);
											jj.add(deco, BorderLayout.CENTER);
											jj.add(infosJeu, BorderLayout.SOUTH);
											this.add(jj, gbc);
											gbc.gridheight = 1;
											gbc.gridwidth = 1;											
										}
									}
								}
							}
						}
					}

				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void actionPerformed(ActionEvent e){
		if(e.getActionCommand().equals("Lancer !")){
			this.actualiser();
			//System.out.println("J'ai cliqu�");
		}

	}

	public void actualiser(){
		System.out.println(this.getComponentCount());
		JLabel j1 = new JLabel("Je suis ici");
		JLabel j2 = new JLabel("Moi aussi");
		cases.get(20).add(j1, BorderLayout.NORTH);
		cases.get(20).add(j2,BorderLayout.NORTH);
		cases.get(20).repaint();
		repaint();
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
	}

	public String affiche(String p){
		String ret = "<html><body><center> ";
		int cpt=0;
		String [] a= p.split(" ");
		for(String f : a){
			if(cpt%2!=0) ret+=" "+f+" <br/> ";
			else ret += " "+f+" ";
			cpt++;
		}
		ret+=" </center></html>";
		return ret;
	}

	public Color couleur(String p){
		if( p.equals("jaune"))
			return Color.YELLOW;
		else
			if (p.equals("bleu roi"))
				return Color.BLUE;
			else
				if(p.equals("vert"))
					return Color.GREEN;
				else
					if(p.equals("bleu ciel"))
						return Color.CYAN;
					else
						if(p.equals("mauve"))
							return Color.PINK;
						else
							if(p.equals("violet"))
								return Color.getColor("purple");
							else
								if(p.equals("orange"))
									return Color.ORANGE;
								else
									if(p.equals("rouge"))
										return Color.RED;

		return Color.BLACK;
	}
}